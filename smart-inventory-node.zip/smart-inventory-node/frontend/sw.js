// Offline-first: app shell = cache-first; API GETs = network-first with cached fallback.
const SHELL = "shell-v1", DATA = "data-v1";
self.addEventListener("install", e => { e.waitUntil(caches.open(SHELL).then(c => c.addAll(["/", "/manifest.json"]))); self.skipWaiting(); });
self.addEventListener("activate", e => e.waitUntil(clients.claim()));
self.addEventListener("fetch", e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== "GET" || u.origin !== location.origin) return;
  if (u.pathname.startsWith("/api/")) {
    e.respondWith(fetch(r).then(res => { const cp = res.clone(); if (res.ok) caches.open(DATA).then(c => c.put(r, cp)); return res; })
      .catch(() => caches.match(r)));
  } else {
    e.respondWith(caches.match(r).then(hit => hit || fetch(r).then(res => { const cp = res.clone(); caches.open(SHELL).then(c => c.put(r, cp)); return res; })));
  }
});
