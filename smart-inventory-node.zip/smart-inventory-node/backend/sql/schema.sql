-- Smart Inventory System - MySQL schema (run in MySQL Workbench: File > Open SQL Script > lightning button)
-- MySQL = transactional core: users, items (live stock), stock ledger.
CREATE DATABASE IF NOT EXISTS smart_inventory;
USE smart_inventory;

CREATE TABLE IF NOT EXISTS businesses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  alert_email VARCHAR(200) NULL
);

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  business_id INT NOT NULL,
  email VARCHAR(200) NOT NULL UNIQUE,
  pw_hash VARCHAR(100) NOT NULL,
  role ENUM('admin','staff') NOT NULL,
  FOREIGN KEY (business_id) REFERENCES businesses(id)
);

CREATE TABLE IF NOT EXISTS items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  business_id INT NOT NULL,
  sku VARCHAR(64) NOT NULL,
  barcode VARCHAR(64) NULL,
  name VARCHAR(200) NOT NULL,
  qty INT NOT NULL DEFAULT 0,
  threshold INT NOT NULL DEFAULT 5,          -- low-stock alert level
  reorder_qty INT NOT NULL DEFAULT 20,
  lead_days INT NOT NULL DEFAULT 3,          -- supplier lead time
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,      -- soft delete keeps history
  UNIQUE KEY uq_item_sku (business_id, sku),
  UNIQUE KEY uq_item_barcode (business_id, barcode),
  KEY ix_item_low (business_id, qty, threshold),
  CONSTRAINT chk_qty_nonneg CHECK (qty >= 0),
  FOREIGN KEY (business_id) REFERENCES businesses(id)
);

-- Append-only ledger of every sale / restock / adjustment (audit trail, source of truth)
CREATE TABLE IF NOT EXISTS stock_movements (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  business_id INT NOT NULL,
  item_id INT NOT NULL,
  delta INT NOT NULL,
  kind ENUM('sale','restock','adjust') NOT NULL,
  client_id VARCHAR(64) NOT NULL,            -- idempotency key (offline retries never double count)
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_client (business_id, client_id),
  KEY ix_move_item_time (item_id, created_at),
  KEY ix_move_biz_time (business_id, created_at)
);
