require("dotenv").config();
const path = require("path"), crypto = require("crypto");
const express = require("express"), jwt = require("jsonwebtoken"), bcrypt = require("bcryptjs");
const { state, initMySQL, initMongo } = require("./db");
const { DailySales, Alert } = require("./models");
const { suggest } = require("./forecast");

const SECRET = process.env.JWT_SECRET || "change-me-in-production";
const MAX_ITEMS = +(process.env.MAX_ITEMS || 100000);          // 100K items per business
const app = express();
app.use(express.json({ limit: "1mb" }));

// ---------- helpers ----------
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const P = () => state.pool;
const dayStr = (back = 0) => new Date(Date.now() - back * 864e5).toISOString().slice(0, 10);
const int = (v, name, { min = -2e9, max = 2e9, def } = {}) => {
  if (v === undefined || v === null || v === "") { if (def !== undefined) return def; throw new HttpError(422, `${name} is required`); }
  const n = Number(v); if (!Number.isInteger(n) || n < min || n > max) throw new HttpError(422, `${name} must be a whole number (${min} to ${max})`); return n; };
const dec = (v, name, def) => { if (v === undefined || v === null || v === "") return def; const n = Number(v);
  if (!Number.isFinite(n) || n < 0 || n > 1e8) throw new HttpError(422, `${name} must be 0 or more`); return n; };
const text = (v, name, max = 200) => { const s = String(v ?? "").trim(); if (!s) throw new HttpError(422, `${name} is required`); return s.slice(0, max); };

// ---------- auth ----------
const sign = u => jwt.sign({ uid: u.id, bid: u.business_id, role: u.role }, SECRET, { expiresIn: "12h" });
const me = (req, res, next) => { try { req.user = jwt.verify((req.headers.authorization || "").replace(/^Bearer /, ""), SECRET); next(); }
  catch { next(new HttpError(401, "Invalid or expired token")); } };
const admin = (req, res, next) => req.user.role === "admin" ? next() : next(new HttpError(403, "Admin only"));

app.post("/api/auth/register", wrap(async (req, res) => {
  const email = text(req.body.email, "email").toLowerCase(), business = text(req.body.business, "business", 120);
  if (String(req.body.password || "").length < 6) throw new HttpError(422, "Password must be at least 6 characters");
  const hash = await bcrypt.hash(req.body.password, 10), c = await P().getConnection();
  try {
    await c.beginTransaction();
    const [b] = await c.query("INSERT INTO businesses (name, alert_email) VALUES (?, ?)", [business, email]);
    const [u] = await c.query("INSERT INTO users (business_id, email, pw_hash, role) VALUES (?, ?, ?, 'admin')", [b.insertId, email, hash]);
    await c.commit();
    res.json({ token: sign({ id: u.insertId, business_id: b.insertId, role: "admin" }), role: "admin" });
  } catch (e) { await c.rollback(); throw e; } finally { c.release(); }
}));

app.post("/api/auth/login", wrap(async (req, res) => {
  const [[u]] = await P().query("SELECT * FROM users WHERE email = ?", [String(req.body.email || "").toLowerCase()]);
  if (!u || !(await bcrypt.compare(String(req.body.password || ""), u.pw_hash))) throw new HttpError(401, "Wrong email or password");
  res.json({ token: sign(u), role: u.role });
}));

app.post("/api/users", me, admin, wrap(async (req, res) => {
  const role = req.body.role === "admin" ? "admin" : "staff";
  if (String(req.body.password || "").length < 6) throw new HttpError(422, "Password must be at least 6 characters");
  await P().query("INSERT INTO users (business_id, email, pw_hash, role) VALUES (?, ?, ?, ?)",
    [req.user.bid, text(req.body.email, "email").toLowerCase(), await bcrypt.hash(req.body.password, 10), role]);
  res.json({ ok: true });
}));

// ---------- stock movement core (MySQL transaction + MongoDB analytics) ----------
async function analytics(bid, itemId, kind, units, newAlert, resolved) {
  try {   // MySQL ledger is the source of truth; a Mongo hiccup must never fail a sale
    if (kind !== "adjust") await DailySales.updateOne({ businessId: bid, itemId, day: dayStr() },
      { $inc: kind === "sale" ? { sold: units } : { restocked: units } }, { upsert: true });
    if (newAlert) await Alert.create({ businessId: bid, itemId, message: newAlert });
    if (resolved) await Alert.updateMany({ businessId: bid, itemId, resolved: false }, { resolved: true });
  } catch (e) { console.error("MongoDB write failed:", e.message); }
}

async function applyMove(user, m) {
  const kind = m.kind;
  if (!["sale", "restock", "adjust"].includes(kind)) return { status: "invalid_kind" };
  if (kind === "adjust" && user.role !== "admin") return { status: "forbidden" };
  const qty = Number(m.qty);
  if (!Number.isInteger(qty) || qty === 0 || (kind !== "adjust" && qty < 0) || Math.abs(qty) > 1e6) return { status: "invalid_qty" };
  const delta = kind === "sale" ? -qty : qty, bid = user.bid;
  const c = await P().getConnection();
  try {
    await c.beginTransaction();
    const [[item]] = m.item_id
      ? await c.query("SELECT id FROM items WHERE business_id=? AND active=1 AND id=?", [bid, m.item_id])
      : await c.query("SELECT id FROM items WHERE business_id=? AND active=1 AND barcode=?", [bid, String(m.barcode ?? "")]);
    if (!item) { await c.rollback(); return { status: "not_found" }; }
    try {
      await c.query("INSERT INTO stock_movements (business_id, item_id, delta, kind, client_id) VALUES (?,?,?,?,?)",
        [bid, item.id, delta, kind, String(m.client_id || crypto.randomUUID()).slice(0, 64)]);
    } catch (e) { await c.rollback(); if (e.code === "ER_DUP_ENTRY") return { status: "duplicate" }; throw e; }
    // atomic conditional update: no read-modify-write race, stock can never go negative
    const [u] = await c.query("UPDATE items SET qty = qty + ? WHERE id = ? AND qty + ? >= 0", [delta, item.id, delta]);
    if (!u.affectedRows) { await c.rollback(); return { status: "insufficient_stock" }; }
    const [[row]] = await c.query("SELECT name, qty, threshold FROM items WHERE id = ?", [item.id]);   // row is locked by our UPDATE
    await c.commit();
    const old = row.qty - delta; let alert = null, resolved = false;
    if (old > row.threshold && row.qty <= row.threshold) alert = `${row.name}: stock ${row.qty} is at/below threshold ${row.threshold}`;   // crossed down -> alert once
    else if (old <= row.threshold && row.qty > row.threshold) resolved = true;                                                     // replenished -> auto-resolve
    await analytics(bid, item.id, kind, Math.abs(delta), alert, resolved);
    if (alert) notify(bid, alert);
    return { status: "ok", qty: row.qty, alert };
  } catch (e) { try { await c.rollback(); } catch {} throw e; } finally { c.release(); }
}

async function notify(bid, msg) {   // in-app alert is already stored; this adds optional e-mail
  console.warn("LOW STOCK:", msg);
  if (!process.env.SMTP_HOST) return;
  try {
    const [[b]] = await P().query("SELECT alert_email FROM businesses WHERE id = ?", [bid]);
    if (!b?.alert_email) return;
    await require("nodemailer").createTransport({ host: process.env.SMTP_HOST, port: +(process.env.SMTP_PORT || 587),
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined })
      .sendMail({ from: process.env.SMTP_FROM || "alerts@smart-inventory.local", to: b.alert_email, subject: "Low stock alert", text: msg });
  } catch (e) { console.error("email failed:", e.message); }
}

const MOVE_HTTP = { not_found: 404, forbidden: 403, invalid_qty: 422, invalid_kind: 422, duplicate: 409, insufficient_stock: 409 };
app.post("/api/stock/move", me, wrap(async (req, res) => {
  const r = await applyMove(req.user, req.body);
  if (r.status !== "ok") throw new HttpError(MOVE_HTTP[r.status] || 400, r.status);
  res.json(r);
}));

app.post("/api/sync", me, wrap(async (req, res) => {      // offline-first: queued scans uploaded in one batch
  const ops = req.body.ops;
  if (!Array.isArray(ops) || ops.length > 500) throw new HttpError(422, "ops must be an array of at most 500");
  const results = []; for (const op of ops) results.push(await applyMove(req.user, op));
  res.json({ results });
}));

// ---------- items CRUD ----------
const itemOut = r => ({ id: r.id, sku: r.sku, barcode: r.barcode, name: r.name, qty: r.qty, threshold: r.threshold,
  reorder_qty: r.reorder_qty, lead_days: r.lead_days, price: Number(r.price), low: r.qty <= r.threshold });

app.post("/api/items", me, admin, wrap(async (req, res) => {
  const b = req.body, bid = req.user.bid;
  const it = { sku: text(b.sku, "sku", 64), name: text(b.name, "name"), barcode: b.barcode ? String(b.barcode).trim().slice(0, 64) : null,
    qty: int(b.qty, "qty", { min: 0, def: 0 }), threshold: int(b.threshold, "threshold", { min: 0, def: 5 }),
    reorder_qty: int(b.reorder_qty, "reorder_qty", { min: 1, def: 20 }), lead_days: int(b.lead_days, "lead_days", { min: 0, max: 365, def: 3 }), price: dec(b.price, "price", 0) };
  const [[{ n }]] = await P().query("SELECT COUNT(*) n FROM items WHERE business_id = ? AND active = 1", [bid]);
  if (n >= MAX_ITEMS) throw new HttpError(422, `Item limit reached (${MAX_ITEMS} per business)`);
  const c = await P().getConnection();
  try {
    await c.beginTransaction();
    const [r] = await c.query("INSERT INTO items (business_id, sku, barcode, name, qty, threshold, reorder_qty, lead_days, price) VALUES (?,?,?,?,?,?,?,?,?)",
      [bid, it.sku, it.barcode, it.name, it.qty, it.threshold, it.reorder_qty, it.lead_days, it.price]);
    if (it.qty) await c.query("INSERT INTO stock_movements (business_id, item_id, delta, kind, client_id) VALUES (?,?,?,'restock',?)", [bid, r.insertId, it.qty, "init-" + crypto.randomUUID()]);
    await c.commit();
    if (it.qty) await analytics(bid, r.insertId, "restock", it.qty);
    res.status(201).json(itemOut({ id: r.insertId, ...it, low: false }));
  } catch (e) { await c.rollback(); throw e; } finally { c.release(); }
}));

app.get("/api/items", me, wrap(async (req, res) => {
  const limit = Math.min(Math.max(+req.query.limit || 50, 1), 200), offset = Math.max(+req.query.offset || 0, 0);
  let sql = "SELECT * FROM items WHERE business_id = ? AND active = 1"; const args = [req.user.bid];
  if (req.query.q) { sql += " AND (name LIKE ? OR sku LIKE ? OR barcode = ?)"; args.push(`%${req.query.q}%`, `%${req.query.q}%`, String(req.query.q)); }
  if (req.query.low === "true") sql += " AND qty <= threshold";
  const [rows] = await P().query(sql + " ORDER BY name LIMIT ? OFFSET ?", [...args, limit, offset]);
  res.json(rows.map(itemOut));
}));

app.get("/api/items/barcode/:code", me, wrap(async (req, res) => {
  const [[r]] = await P().query("SELECT * FROM items WHERE business_id = ? AND barcode = ? AND active = 1", [req.user.bid, req.params.code]);
  if (!r) throw new HttpError(404, "Unknown barcode"); res.json(itemOut(r));
}));

app.patch("/api/items/:id", me, admin, wrap(async (req, res) => {
  const b = req.body, sets = [], args = [];
  const add = (col, v) => { sets.push(`${col} = ?`); args.push(v); };
  if (b.name !== undefined) add("name", text(b.name, "name"));
  if (b.barcode !== undefined) add("barcode", b.barcode ? String(b.barcode).trim().slice(0, 64) : null);
  if (b.threshold !== undefined) add("threshold", int(b.threshold, "threshold", { min: 0 }));
  if (b.reorder_qty !== undefined) add("reorder_qty", int(b.reorder_qty, "reorder_qty", { min: 1 }));
  if (b.lead_days !== undefined) add("lead_days", int(b.lead_days, "lead_days", { min: 0, max: 365 }));
  if (b.price !== undefined) add("price", dec(b.price, "price", 0));
  if (sets.length) { const [r] = await P().query(`UPDATE items SET ${sets.join(", ")} WHERE id = ? AND business_id = ? AND active = 1`, [...args, req.params.id, req.user.bid]);
    if (!r.affectedRows) throw new HttpError(404, "Item not found"); }
  const [[row]] = await P().query("SELECT * FROM items WHERE id = ? AND business_id = ? AND active = 1", [req.params.id, req.user.bid]);
  if (!row) throw new HttpError(404, "Item not found"); res.json(itemOut(row));
}));

app.delete("/api/items/:id", me, admin, wrap(async (req, res) => {   // soft delete keeps sales history for forecasts
  const [r] = await P().query("UPDATE items SET active = 0 WHERE id = ? AND business_id = ?", [req.params.id, req.user.bid]);
  if (!r.affectedRows) throw new HttpError(404, "Item not found"); res.status(204).end();
}));

// ---------- alerts, dashboard, trends, forecast ----------
const openAlerts = async (bid, n = 50) => (await Alert.find({ businessId: bid, resolved: false }).sort({ createdAt: -1 }).limit(n).lean())
  .map(a => ({ id: String(a._id), item_id: a.itemId, message: a.message, created: a.createdAt }));

app.get("/api/alerts", me, wrap(async (req, res) => res.json(await openAlerts(req.user.bid))));
app.post("/api/alerts/:id/resolve", me, wrap(async (req, res) => {
  await Alert.updateOne({ _id: req.params.id, businessId: req.user.bid }, { resolved: true }); res.json({ ok: true }); }));

app.get("/api/dashboard", me, wrap(async (req, res) => {
  const bid = req.user.bid;
  const [[s]] = await P().query("SELECT COUNT(*) total, COALESCE(SUM(qty <= threshold), 0) low, COALESCE(SUM(qty * price), 0) value FROM items WHERE business_id = ? AND active = 1", [bid]);
  const [sold] = await DailySales.aggregate([{ $match: { businessId: bid, day: dayStr() } }, { $group: { _id: null, n: { $sum: "$sold" } } }]);
  res.json({ items: s.total, low_stock: Number(s.low), stock_value: Math.round(Number(s.value) * 100) / 100,
    sold_today: sold?.n || 0, alerts: await openAlerts(bid, 10), limit: MAX_ITEMS });
}));

app.get("/api/trends", me, wrap(async (req, res) => {
  const n = Math.min(Math.max(+req.query.days || 30, 7), 180), match = { businessId: req.user.bid, day: { $gte: dayStr(n - 1) } };
  if (req.query.item_id) match.itemId = +req.query.item_id;
  const rows = await DailySales.aggregate([{ $match: match }, { $group: { _id: "$day", s: { $sum: "$sold" }, r: { $sum: "$restocked" } } }]);
  const by = Object.fromEntries(rows.map(r => [r._id, r]));
  const days = Array.from({ length: n }, (_, i) => dayStr(n - 1 - i));
  res.json({ days, sales: days.map(d => by[d]?.s || 0), restocks: days.map(d => by[d]?.r || 0) });
}));

app.get("/api/forecast", me, wrap(async (req, res) => {     // predictive restocking: last 28 days of sales per item
  const bid = req.user.bid, limit = Math.min(+req.query.limit || 50, 200);
  const docs = await DailySales.find({ businessId: bid, day: { $gte: dayStr(27) }, sold: { $gt: 0 } }).lean();
  if (!docs.length) return res.json([]);
  const first = await DailySales.findOne({ businessId: bid }).sort({ day: 1 }).select("day").lean();
  const start = first && first.day > dayStr(27) ? first.day : dayStr(27);   // new shops: don't count days before recording began
  const days = []; for (let d = new Date(start + "T00:00:00Z"); d.toISOString().slice(0, 10) <= dayStr(); d.setUTCDate(d.getUTCDate() + 1)) days.push(d.toISOString().slice(0, 10));
  const per = new Map(); for (const d of docs) { if (!per.has(d.itemId)) per.set(d.itemId, {}); per.get(d.itemId)[d.day] = d.sold; }
  const [items] = await P().query("SELECT id, name, sku, qty, lead_days FROM items WHERE business_id = ? AND active = 1 AND id IN (?)", [bid, [...per.keys()]]);
  const out = [];
  for (const i of items) { const r = suggest(days.map(d => per.get(i.id)[d] || 0), i.qty, i.lead_days);
    if (r) out.push({ item_id: i.id, name: i.name, sku: i.sku, qty: i.qty, history_days: days.length, ...r }); }
  res.json(out.sort((a, b) => a.days_left - b.days_left).slice(0, limit));
}));

// ---------- frontend + errors ----------
app.use("/api", (req, res) => res.status(404).json({ detail: "Not found" }));
app.use(express.static(path.join(__dirname, "..", "..", "frontend")));
app.use((e, req, res, next) => {
  if (e.code === "ER_DUP_ENTRY") return res.status(409).json({ detail: "Already exists (duplicate SKU, barcode or email)" });
  if (e.name === "CastError") return res.status(404).json({ detail: "Not found" });
  if (e.type === "entity.parse.failed") return res.status(400).json({ detail: "Bad JSON" });
  const s = e.status || 500; if (s === 500) console.error(e);
  res.status(s).json({ detail: s === 500 ? "Server error" : e.message });
});

async function start(port = process.env.PORT || 3000) {
  await initMySQL(); await initMongo();
  return new Promise(r => { const srv = app.listen(port, () => { console.log(`Smart Inventory running at http://localhost:${srv.address().port}`); r(srv); }); });
}
if (require.main === module) start().catch(e => { console.error("Startup failed:", e.message); process.exit(1); });
module.exports = { app, start };
