// Restock suggestion from daily units sold (oldest -> newest): exponential smoothing + short-term linear trend.
function suggest(series, qty, leadDays, safetyDays = 3, coverDays = 14) {
  if (!series.length || series.reduce((a, b) => a + b, 0) === 0) return null;
  let level = series[0];
  for (const x of series.slice(1)) level = 0.3 * x + 0.7 * level;
  const w = series.slice(-14), n = w.length, xm = (n - 1) / 2, ym = w.reduce((a, b) => a + b, 0) / n;
  let num = 0, den = 0;
  w.forEach((y, i) => { num += (i - xm) * (y - ym); den += (i - xm) ** 2; });
  const slope = num / (den || 1);
  const demand = Math.max(0, level + slope * (leadDays / 2));
  if (demand === 0) return null;
  const daysLeft = qty / demand, target = demand * (leadDays + coverDays + safetyDays);
  const needs = daysLeft <= leadDays + safetyDays + 4;
  return { daily_demand: +demand.toFixed(2), days_left: +daysLeft.toFixed(1),
    suggested_order: needs ? Math.max(0, Math.ceil(target - qty)) : 0,
    urgency: daysLeft <= leadDays ? "critical" : needs ? "soon" : "ok",
    trend: slope > 0.05 ? "up" : slope < -0.05 ? "down" : "flat" };
}
module.exports = { suggest };
