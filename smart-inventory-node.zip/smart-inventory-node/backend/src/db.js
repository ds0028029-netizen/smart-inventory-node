require("dotenv").config();
const fs = require("fs"), path = require("path");
const mysql = require("mysql2/promise");
const mongoose = require("mongoose");

const state = { pool: null };
const conf = () => ({ host: process.env.MYSQL_HOST || "localhost", port: +(process.env.MYSQL_PORT || 3306),
  user: process.env.MYSQL_USER || "root", password: process.env.MYSQL_PASSWORD || "" });
const dbName = () => process.env.MYSQL_DATABASE || "smart_inventory";

async function initMySQL() {
  const name = dbName();
  const boot = await mysql.createConnection({ ...conf(), multipleStatements: true });
  await boot.query(`CREATE DATABASE IF NOT EXISTS \`${name}\``);
  await boot.query(`USE \`${name}\``);
  // same schema.sql you can run by hand in Workbench; its CREATE DATABASE / USE lines are skipped here
  const sql = fs.readFileSync(path.join(__dirname, "..", "sql", "schema.sql"), "utf8").replace(/^\s*(CREATE DATABASE|USE)\b.*;\s*$/gim, "");
  await boot.query(sql);
  await boot.end();
  state.pool = mysql.createPool({ ...conf(), database: name, connectionLimit: 20, decimalNumbers: true });
}

async function initMongo() {
  await mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/smart_inventory", { maxPoolSize: 50, serverSelectionTimeoutMS: 5000 });
  const { DailySales, Alert } = require("./models");
  await Promise.all([DailySales.init(), Alert.init()]);   // make sure indexes exist
}

async function closeAll() { if (state.pool) await state.pool.end(); await mongoose.disconnect(); }
module.exports = { state, initMySQL, initMongo, closeAll, dbName };
