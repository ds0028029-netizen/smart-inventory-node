// Demo data: 6 hand-made scenarios + 2000 random items, 30 days of sales.  Run: npm run seed   (login demo@shop.com / demo123)
const bcrypt = require("bcryptjs");
const { state, initMySQL, initMongo, closeAll } = require("./db");
const { DailySales, Alert } = require("./models");
const rnd = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
const gauss = (m, s) => m + s * Math.sqrt(-2 * Math.log(1 - Math.random())) * Math.cos(2 * Math.PI * Math.random());
const flat = n => Array.from({ length: 30 }, () => Math.max(0, Math.round(gauss(n, 1))));
const growth = Array.from({ length: 30 }, (_, i) => Math.max(0, Math.round(2 + i * 0.4 + gauss(0, 1))));
const decl = Array.from({ length: 30 }, (_, i) => Math.max(0, Math.round(14 - i * 0.4 + gauss(0, 1))));
const SCEN = [["Rice 1kg (fast, nearly out)", "1001", 22, 10, 3, flat(9)], ["Cooking oil (growing demand)", "1002", 60, 10, 4, growth],
  ["Soap (steady, well stocked)", "1003", 400, 20, 3, flat(3)], ["Notebook (declining)", "1004", 90, 10, 5, decl],
  ["Batteries (already low)", "1005", 4, 8, 3, flat(2)], ["Old calendar (dead stock)", "1006", 150, 5, 7, Array(30).fill(0)]];

(async () => {
  await initMySQL(); await initMongo(); const P = state.pool;
  const [[ex]] = await P.query("SELECT id FROM users WHERE email = 'demo@shop.com'");
  if (ex) { console.log("Demo data already exists (login demo@shop.com / demo123). Drop the databases to reseed."); return; }
  const [b] = await P.query("INSERT INTO businesses (name, alert_email) VALUES ('Demo Shop', 'demo@shop.com')"); const bid = b.insertId;
  const hash = bcrypt.hashSync("demo123", 10);
  await P.query("INSERT INTO users (business_id, email, pw_hash, role) VALUES (?,?,?,'admin'),(?,?,?,'staff')", [bid, "demo@shop.com", hash, bid, "staff@shop.com", hash]);
  const rows = [], pats = new Map();
  for (const [name, bc, qty, th, ld, pat] of SCEN) { rows.push([bid, "S" + bc, bc, name, qty, th, 20, ld, [20, 55, 120][rnd(0, 2)]]); pats.set("S" + bc, pat); }
  for (let k = 0; k < 2000; k++) { const sku = "P" + String(k).padStart(5, "0");
    rows.push([bid, sku, "9" + String(k).padStart(6, "0"), "Product " + k, rnd(0, 200), 10, 20, rnd(2, 7), +(5 + Math.random() * 495).toFixed(2)]);
    pats.set(sku, Array.from({ length: 30 }, () => Math.random() < 0.5 ? rnd(0, 6) : 0)); }
  for (let i = 0; i < rows.length; i += 500) await P.query("INSERT INTO items (business_id, sku, barcode, name, qty, threshold, reorder_qty, lead_days, price) VALUES ?", [rows.slice(i, i + 500)]);
  const [items] = await P.query("SELECT id, sku, name, qty, threshold FROM items WHERE business_id = ?", [bid]);
  const docs = [], alerts = [];
  for (const it of items) {
    if (it.qty <= it.threshold && it.sku.startsWith("S")) alerts.push({ businessId: bid, itemId: it.id, message: `${it.name}: stock ${it.qty} is at/below threshold ${it.threshold}` });
    pats.get(it.sku).forEach((sold, i) => { if (sold) docs.push({ businessId: bid, itemId: it.id, day: new Date(Date.now() - (29 - i) * 864e5).toISOString().slice(0, 10), sold }); });
  }
  for (let i = 0; i < docs.length; i += 10000) await DailySales.insertMany(docs.slice(i, i + 10000), { ordered: false });
  await Alert.insertMany(alerts);
  console.log(`Seeded ${items.length} items and ${docs.length} daily sales records. Login: demo@shop.com / demo123`);
})().catch(e => console.error("Seed failed:", e.message)).finally(closeAll);
