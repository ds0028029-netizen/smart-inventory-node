const mongoose = require("mongoose");

// MongoDB = analytics + notifications. One small document per item per day, updated with atomic $inc.
// (Sales history for predictions & charts; far cheaper to read than scanning millions of ledger rows.)
const dailySales = new mongoose.Schema({
  businessId: { type: Number, required: true },
  itemId: { type: Number, required: true },
  day: { type: String, required: true },            // "YYYY-MM-DD" (UTC)
  sold: { type: Number, default: 0 },
  restocked: { type: Number, default: 0 },
}, { versionKey: false });
dailySales.index({ businessId: 1, itemId: 1, day: 1 }, { unique: true });
dailySales.index({ businessId: 1, day: 1 });

const alert = new mongoose.Schema({
  businessId: { type: Number, required: true },
  itemId: { type: Number, required: true },
  message: { type: String, required: true },
  resolved: { type: Boolean, default: false },
}, { timestamps: { createdAt: "createdAt", updatedAt: false }, versionKey: false });
alert.index({ businessId: 1, resolved: 1, createdAt: -1 });
alert.index({ itemId: 1, resolved: 1 });

module.exports = { DailySales: mongoose.model("DailySales", dailySales), Alert: mongoose.model("Alert", alert) };
