// Speed test: npm run loadtest -- [requests] [concurrency]   (server running + demo data seeded)
const N = +process.argv[2] || 2000, T = +process.argv[3] || 20, BASE = `http://localhost:${process.env.PORT || 3000}/api`;
(async () => {
  const login = await fetch(BASE + "/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: "demo@shop.com", password: "demo123" }) });
  const H = { "Content-Type": "application/json", Authorization: "Bearer " + (await login.json()).token };
  const lat = []; let ok = 0, next = 0;
  const worker = async () => { while (next < N) { const i = next++, t = performance.now();
    const r = await fetch(BASE + "/stock/move", { method: "POST", headers: H, body: JSON.stringify({ kind: i % 2 ? "restock" : "sale", qty: 1, barcode: "9" + String(Math.floor(Math.random() * 2000)).padStart(6, "0"), client_id: crypto.randomUUID() }) });
    lat.push(performance.now() - t); if (r.ok) ok++; await r.arrayBuffer(); } };
  const t0 = performance.now(); await Promise.all(Array.from({ length: T }, worker)); const sec = (performance.now() - t0) / 1000;
  lat.sort((a, b) => a - b);
  console.log(`${N} requests, ${T} parallel: ${(N / sec).toFixed(0)} tx/sec | ok ${ok}/${N} | avg ${(lat.reduce((a, b) => a + b) / N).toFixed(0)} ms | p95 ${lat[Math.floor(N * .95)].toFixed(0)} ms`);
  console.log(`=> at this speed: ${(N / sec * 86400 / 1e6).toFixed(1)}M transactions/day (target 1M)`);
  for (const p of ["/dashboard", "/forecast", "/trends?days=30", "/items?limit=50"]) { const t = performance.now(); await (await fetch(BASE + p, { headers: H })).arrayBuffer(); console.log(`GET ${p.padEnd(18)} ${(performance.now() - t).toFixed(0)} ms`); }
})();
