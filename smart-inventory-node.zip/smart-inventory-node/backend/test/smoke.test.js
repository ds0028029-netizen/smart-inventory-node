const stamp = Date.now();
process.env.MYSQL_DATABASE = `si_test_${stamp}`; process.env.MONGO_URI = `mongodb://127.0.0.1:27017/si_test_${stamp}`;
process.env.MAX_ITEMS = "3"; process.env.JWT_SECRET = "test-secret-test-secret-test-secret";
const { test, after } = require("node:test"), assert = require("node:assert/strict");
const mongoose = require("mongoose"), { start } = require("../src/server"), db = require("../src/db"), { DailySales } = require("../src/models");

test("full inventory flow (MySQL + MongoDB)", async () => {
  const srv = await start(0), base = `http://localhost:${srv.address().port}/api`;
  after(async () => { srv.close(); await db.state.pool.query(`DROP DATABASE \`${process.env.MYSQL_DATABASE}\``); await mongoose.connection.dropDatabase(); await db.closeAll(); });
  const call = async (path, method = "GET", body, token) => { const r = await fetch(base + path, { method, headers: { "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
    return { s: r.status, j: r.status === 204 ? null : await r.json() }; };
  const A = (await call("/auth/register", "POST", { email: "a@x.com", password: "secret1", business: "Shop" })).j.token;
  assert.equal((await call("/users", "POST", { email: "s@x.com", password: "secret1", role: "staff" }, A)).s, 200);
  const S = (await call("/auth/login", "POST", { email: "s@x.com", password: "secret1" })).j.token;
  assert.equal((await call("/auth/login", "POST", { email: "s@x.com", password: "bad" })).s, 401);
  const item = (await call("/items", "POST", { sku: "A1", name: "Rice", barcode: "111", qty: 20, threshold: 5 }, A)).j;
  assert.equal((await call("/items", "POST", { sku: "B", name: "x" }, S)).s, 403);                       // RBAC
  assert.equal((await call("/items", "POST", { sku: "A1", name: "dup" }, A)).s, 409);                    // unique SKU
  let r = (await call("/stock/move", "POST", { kind: "sale", qty: 12, barcode: "111", client_id: "k1" }, S)).j; assert.equal(r.qty, 8); assert.equal(r.alert, null);
  r = (await call("/stock/move", "POST", { kind: "sale", qty: 4, barcode: "111", client_id: "k2" }, S)).j; assert.equal(r.qty, 4); assert.match(r.alert, /threshold/);   // alert on crossing
  assert.equal((await call("/stock/move", "POST", { kind: "sale", qty: 4, barcode: "111", client_id: "k2" }, S)).s, 409);   // idempotent
  assert.equal((await call("/stock/move", "POST", { kind: "sale", qty: 99, barcode: "111" }, S)).s, 409);                    // never negative
  assert.equal((await call("/alerts", "GET", null, S)).j.length, 1);
  let d = (await call("/dashboard", "GET", null, S)).j; assert.equal(d.low_stock, 1); assert.equal(d.sold_today, 16);
  const docs = []; for (let n = 1; n <= 14; n++) docs.push({ businessId: 1, itemId: item.id, day: new Date(Date.now() - n * 864e5).toISOString().slice(0, 10), sold: 3 });
  await DailySales.insertMany(docs);
  const f = (await call("/forecast", "GET", null, S)).j; assert.ok(f.length && ["critical", "soon"].includes(f[0].urgency) && f[0].suggested_order > 0);
  const t = (await call("/trends?days=14", "GET", null, S)).j; assert.equal(t.days.length, 14); assert.ok(t.sales.reduce((a, b) => a + b) > 0);
  const sy = (await call("/sync", "POST", { ops: [{ kind: "restock", qty: 30, barcode: "111", client_id: "o1" }] }, S)).j; assert.equal(sy.results[0].qty, 34);
  assert.equal((await call("/alerts", "GET", null, S)).j.length, 0);                                     // auto-resolved
  await call("/items", "POST", { sku: "A2", name: "b", qty: 0, threshold: 5 }, A); await call("/items", "POST", { sku: "A3", name: "c", qty: 1, threshold: 5 }, A);
  assert.equal((await call("/dashboard", "GET", null, S)).j.low_stock, 2);
  assert.equal((await call("/items", "POST", { sku: "A4", name: "d" }, A)).s, 422);                       // 100K cap (3 in test)
  assert.equal((await call(`/items/${item.id}`, "PATCH", { threshold: 10 }, A)).j.threshold, 10);
  assert.equal((await call(`/items/${item.id}`, "DELETE", null, A)).s, 204);
});
