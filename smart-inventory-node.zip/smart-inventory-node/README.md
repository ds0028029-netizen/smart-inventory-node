# Smart Inventory System - Full Stack Development 2
**HTML + JavaScript (PWA) frontend · Node.js/Express backend · MySQL (Workbench) + MongoDB**

Lightweight, real-time inventory for small businesses: low-stock alerts, predictive restocking, barcode entry, offline-first.

## 1. Why two databases (polyglot persistence)
| Database | Holds | Why |
|---|---|---|
| **MySQL** (managed in Workbench) | `businesses`, `users` (admin/staff), `items` (live stock), `stock_movements` (ledger) | Money-like data needs ACID transactions, foreign keys, unique keys and a `CHECK (qty >= 0)` so stock can never go negative |
| **MongoDB** | `dailysales` (one doc per item per day), `alerts` | Write-heavy time-series counters (`$inc` upsert) and flexible notification documents; reading 28 small docs per item is far faster than scanning millions of ledger rows for forecasts |

**Flow of one sale:** HTML page -> `POST /api/stock/move` -> MySQL transaction (ledger insert + atomic `UPDATE qty = qty - n WHERE qty - n >= 0`) -> after commit, MongoDB `$inc` on today's `dailysales` document -> if stock crossed the threshold, create an alert (and optional e-mail). The MySQL ledger is the source of truth; a MongoDB hiccup never fails a sale.

## 2. Requirements coverage
| Requirement | Where |
|---|---|
| Low-stock alert when threshold crossed | `applyMove()` in `server.js` - alert created once on the downward crossing, auto-resolved on restock; dashboard + optional SMTP e-mail |
| Predictive restocking | `forecast.js` - exponential smoothing + 14-day trend, uses MongoDB sales history; shows days left, urgency, suggested order |
| Barcode scanning | USB/Bluetooth scanner (type + Enter) and phone camera (`BarcodeDetector`) in the Scan page |
| 100K items / business | enforced in `POST /api/items` (`MAX_ITEMS`) |
| CRUD | `/api/items` (soft delete keeps history) |
| Sales history | MongoDB `dailysales` + MySQL `stock_movements` |
| Admin / staff roles | JWT carries role; only admin: item create/edit/delete, users, adjustments |
| 1M transactions/day | about 12 tx/s average, about 150 at peak; each sale = 1 insert + 1 row update + 1 `$inc`; connection pool, idempotency key, batch `/api/sync` |
| Dashboard + trend charts | `frontend/index.html` (KPIs, alerts, sales vs restock chart, restock table) |
| Offline-first | service worker + local queue; scans sync later via `/api/sync`, duplicates ignored (`UNIQUE(business_id, client_id)`) |

## 3. Setup on Windows
1. Install **Node.js LTS** (nodejs.org), **MySQL Server + MySQL Workbench**, and **MongoDB Community Server** (+ Compass, optional). Make sure both database services are running.
2. In PowerShell (one command per line):
```powershell
cd smart-inventory-node\backend
npm install
copy .env.example .env
notepad .env          # put your MySQL root password in MYSQL_PASSWORD
npm run seed          # optional demo data
npm start
```
3. Open **http://localhost:3000**. Demo login after seeding: `demo@shop.com` / `demo123`. Or click *Create business* for a fresh shop.

The server creates the MySQL database and tables by itself on first start.

## 4. Using MySQL Workbench
1. Open Workbench -> click your **Local instance MySQL** connection (host `localhost`, port `3306`, user `root`).
2. (Optional) *File -> Open SQL Script* -> `backend/sql/schema.sql` -> click the lightning icon to create the schema manually.
3. Refresh the **SCHEMAS** panel -> `smart_inventory` -> Tables. Useful queries:
```sql
USE smart_inventory;
SELECT name, qty, threshold FROM items WHERE qty <= threshold;                 -- low stock
SELECT kind, COUNT(*), SUM(ABS(delta)) FROM stock_movements GROUP BY kind;     -- ledger summary
SELECT i.name, m.delta, m.kind, m.created_at FROM stock_movements m JOIN items i ON i.id = m.item_id ORDER BY m.id DESC LIMIT 20;
```
4. Tip: *Database -> Reverse Engineer* gives an ER diagram of the 4 tables.

MongoDB (Compass -> `mongodb://127.0.0.1:27017` -> database `smart_inventory`): collections `dailysales`, `alerts`.

## 5. API
| Method | Path | Role |
|---|---|---|
| POST | `/api/auth/register`, `/api/auth/login` | public |
| POST | `/api/users` | admin |
| GET / POST / PATCH / DELETE | `/api/items`, `/api/items/:id`; GET `/api/items/barcode/:code` | read: all, write: admin |
| POST | `/api/stock/move` `{kind, qty, barcode or item_id, client_id}` | all (adjust: admin) |
| POST | `/api/sync` (up to 500 queued ops) | all |
| GET | `/api/dashboard`, `/api/alerts`, `/api/trends`, `/api/forecast` | all |
| POST | `/api/alerts/:id/resolve` | all |

## 6. Test and speed
```powershell
npm test                     # needs both databases running; uses throw-away databases
npm run loadtest -- 2000 20  # after npm run seed and npm start
```
A few load-test requests may be rejected: they try to sell items that are already at 0 stock, which is the correct behaviour.

## 7. Project structure
```
backend/src/server.js    API, auth, stock transaction, alerts, forecast endpoints
backend/src/db.js        MySQL pool + MongoDB connection
backend/src/models.js    MongoDB schemas (dailysales, alerts)
backend/src/forecast.js  restocking prediction
backend/src/seed.js      demo data      backend/src/loadtest.js  speed test
backend/sql/schema.sql   MySQL tables (run in Workbench)
backend/test/            end-to-end test
frontend/                index.html, sw.js, manifest.json (offline-first PWA)
```

## 8. Possible improvements
Rebuild MongoDB history from the MySQL ledger, HTTPS reverse proxy, login rate limit, CSV import, SMS/WhatsApp alerts, purchase orders from forecast, partition `stock_movements` by month for very large shops.
